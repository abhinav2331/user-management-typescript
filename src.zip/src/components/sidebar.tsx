import React, { FC } from 'react';
import { Link } from "react-router-dom";

const Sidebar: FC = () => {
    return (
        <div className='sidebar'>
            Sidebar
            <hr />           
            

        </div>
    );
}

export default Sidebar;
